library(shiny)
library(dplyr)
library(ggplot2)
library(RMySQL)
library(DT)
library(datasets)
source("global.r")
shinyServer(function(input, output){
  
  datasetInput <- reactive({
    #dataSort()
    tmp=x%>%filter(x[,4] == input$companySet)
    y1=array(1:length(tmp[,1]))
    for (i in 1:length(tmp[,1])) {
      y1[i]=tmp[,6][i]
    }
    row.names(y1)<-tmp[,2]
    y1
  })#公司中的不同產品
  datasetInputTable <- reactive({
    y3=data.frame(Product=rownames(datasetInput()),Carbon_Footprint=datasetInput())
  })
  datasetCompany <- reactive({
    #dataSort()
    y2=array(1:length(unique(x[,4])))
    for (i in 1:length(unique(x[,4]))) {
      tmp=x%>%filter(x[,4]== unique(x[,4])[i])
      tmp_value=sum(tmp[,6])
      y2[i]=tmp_value
    }
    row.names(y2)<-unique(x[,4])
    y2
  })
  datasetCompanyTable <- reactive({
    y4=data.frame(Company=rownames(datasetCompany()),Carbon_Footprint=datasetCompany())
  })
  output$barPlot <- renderPlot({
    barplot(datasetCompany(),main="All Sum Carbon Footprint of Each Company in Bar plot",xlab = "Company",ylab = "Carbon Footprint (g)")
  })
  output$piePlot <- renderPlot({
    pie(datasetInput(),main = "Product of this Company")
  })
  output$boxPlot <- renderPlot({
    boxplot(formula = Carbon_Footprint ~ Company, # Y ~ X (代表X和Y軸要放的數值) 
            main="All Sum Carbon Footprint of Each Company in Box plot",
            data = datasetCompanyTable(),       # 資料
            xlab = "Company",          # X軸名稱
            ylab = "Carbon Footprint (g)",    # Y軸名稱
            col ="gray")             # 顏色
  })
  output$text <- renderUI({ 
    HTML(paste(h3("碳足跡介紹"),
               h4("碳足跡(Carbon Footprint)的定義為一項活動或產品從原料取得、工廠製造、配送、銷售、使用到最後廢棄回收等整個生命週期過程所直接與間接產生的溫室氣體排放量。相較於一般大家瞭解的溫室氣體排放量，碳足跡的差異之處在於從消費者端出發，破除「有煙囪才有污染」的觀念。"), 
               h4("企業及產業溫室氣體的排放，一般是指製造部分相關的排放，但產品碳足跡排放尚須包含產品原物料的開採與製造、組裝、運輸，一直到使用及廢棄處理或回收時所產生的溫室氣體排放量。"),
               ("資料來源：台灣碳足跡標籤|環境資訊中心 https://e-info.org.tw/node/211962"),
               sep = '<br/>'))
  })
  output$summary <- renderPrint({
    summary(datasetInput())
  })
  output$table <- DT::renderDataTable(
    DT::datatable(x[,-6])
  )
  output$table2 <- renderTable(
    head(datasetInputTable())
  )
 
  output$img <- renderImage({ 
    return(list(
      src = "co2about01.png", 
      contentType = "png",
      width = 820,
      height = 320,
      alt = "Face" 
    )) 
  }, deleteFile = FALSE) 
  
  output$downloadPng <- downloadHandler(
    filename = function() {
      paste(input$pngSet, ".png", sep = "")
    },
    content = function(file) {
      png(file)
      if(input$pngSet=="Pie chart"){
        print(pie(datasetInput(),main = "Product of this Company"))
        #pie(datasetInput(),main = "Product of this Company")
      }else if(input$pngSet=="Bar plot"){
        print( barplot(datasetCompany(),main="All Sum Carbon Footprint of Each Company in Bar plot",xlab = "Company",ylab = "Carbon Footprint (g)"))
        #barplot(datasetCompany(),main="All Sum Carbon Footprint of Each Company in Bar plot",xlab = "Company",ylab = "Carbon Footprint (g)")
      }else{
        print(
          boxplot(formula = Carbon_Footprint ~ Company, # Y ~ X (代表X和Y軸要放的數值) 
                  main="All Sum Carbon Footprint of Each Company in Box plot",
                  data = datasetCompanyTable(),       # 資料
                  xlab = "Company",          # X軸名稱
                  ylab = "Carbon Footprint (g)",    # Y軸名稱
                  col ="gray")  
        )
      }
      dev.off()  # turn the device off
    }
    # content is a function with argument file. content writes the plot to the device
    
  )
  output$downloadCsv <- downloadHandler(
    filename = function() {
      paste(input$csvSet, ".csv", sep = "")
    },
    content = function(file) {
      if(input$csvSet=="Product of this Company"){
        write.csv(datasetInputTable(), file, row.names = FALSE)
      }else{
        write.csv(datasetCompanyTable(), file, row.names = FALSE)
      }
    
    }
  )
  
  
})