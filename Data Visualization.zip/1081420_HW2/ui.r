library(shiny)
library(plotly)
source("global.r")
shinyUI(fluidPage(
  
  titlePanel("Carbon Footprint"),
  sidebarLayout(
    sidebarPanel(
      selectInput("companySet", "Choose a Company:",
                  choices = unique(x[,4])),
      
      selectInput("pngSet", "Choose a png:",
                  choices = c("Pie chart","Bar plot","Box plot")),
      downloadButton("downloadPng", "Download .phg"),
      
      selectInput("csvSet", "Choose a csv:",
                  choices = c("Product of this Company","All Sum Carbon Footprint of Each Company")),
      
      downloadButton("downloadCsv", "Download .csv")
      
    ),
    mainPanel(
      imageOutput('img'),
      tabsetPanel(
        tabPanel("Carbon Footprint Introduction",htmlOutput("text")),
        tabPanel("Pie chart", plotOutput("piePlot")), 
        tabPanel("Bar plot",plotOutput("barPlot")),
        tabPanel("Box plot",plotOutput("boxPlot")),
        tabPanel("Summary", h3("Summary of this Company"),verbatimTextOutput("summary")),
        tabPanel("Company's Product",h3("Product of this Company"), tableOutput("table2"))
      ),
      h3("All Company's Product"),
      DT::dataTableOutput("table")
    )
    
  )
))