library(dplyr)
x=read.csv("cfp_p_01_20210522112339.csv",sep = ",",header = T)
x[,3]=as.character(x[,3])
x=filter(x,x[,3]!="-")
##########################################去掉過少的資料
y=array(1:length(unique(x[,4])))
for (i in 1:length(unique(x[,4]))) {
  tmp=x%>%filter(x[,4]== unique(x[,4])[i])
  if(length(tmp[,1])<5){
    y[i]=as.character(tmp[,4][1])
  }else{
    y[i]=""
  }
}
y=y[which(y!="")]
x[,4]=as.character(x[,4])
for(i in 1:length(y)){
  x=filter(x,x[,4]!=y[i])#固定地區
}
##############################################
tmp=vector("numeric", length(x[,1]))
for (i in 1:length(x[,1])) {
  
  if(substr(x[,3][i],nchar(x[,3][i])-1,nchar(x[,3][i]))=="kg"){
    value=as.character(substr(x[,3][i],1,nchar(x[,3][i])-2))
    value=as.numeric(value)
    value=value*1000
    tmp[i]=value
  }else{
    value=as.character(substr(x[,3][i],1,nchar(x[,3][i])-1))
    value=as.numeric(value)
    #value=value/1000
    tmp[i]=value
  }
}
x[,6]=tmp
##處理重量單位數字
